//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// integration_context.h
// Created by Greg on 2/20/2024.
// Copyright (C) 2024 Presage Security, Inc.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 3 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, write to the Free Software Foundation,
// Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once
// === standard library includes (if any) ===
#include <filesystem>
// === third-party includes (if any) ===
#include "nlohmann/json.hpp"
#include <mediapipe/framework/timestamp.h>
#include <physiology/modules/messages/metrics.pb.h>
#include <physiology/modules/web_client.h>
// === local includes (if any) ===
#include "settings.h"


namespace presage::smartspectra::container {

class IntegrationContextBase {
public:
    virtual absl::Status OnFrameProcessed(mediapipe::Timestamp frame_timestamp);

    virtual absl::Status Initialize();
};

template<settings::IntegrationMode TIntegrationMode>
class IntegrationContext;

//TODO: come up with a Reset() mechanism to accommodate "spot" mode reruns

template<>
class IntegrationContext<settings::IntegrationMode::Grpc> : public IntegrationContextBase {
public:
    typedef physiology::MetricsBuffer MetricsType;
    explicit IntegrationContext(
        const settings::GeneralSettings& general_settings,
        const settings::IntegrationSettings<settings::IntegrationMode::Grpc>& integration_settings
    ) :
        print_metrics(general_settings.verbosity_level > 0) {};

    absl::Status HandlePreprocessedData(const physiology::MetricsBuffer& buffer, mediapipe::Timestamp output_timestamp);

    std::function<absl::Status(const MetricsType&)> OnMetricsOutput = [](const MetricsType&){ return absl::OkStatus(); };
private:
    bool print_metrics = true;
};

template<>
class IntegrationContext<settings::IntegrationMode::JsonFileOnDisk> : public IntegrationContextBase {
public:
    typedef int MetricsType; // void type, not sure what to put here
    explicit IntegrationContext(
        const settings::GeneralSettings& settings,
        const settings::IntegrationSettings<settings::IntegrationMode::JsonFileOnDisk>& integration_settings
    )
        : json_directory_path(settings.output_path) {};

    absl::Status HandlePreprocessedData(const nlohmann::json& json, mediapipe::Timestamp output_timestamp);

    std::function<absl::Status(const MetricsType&)> OnMetricsOutput = [](const MetricsType&){ return absl::OkStatus(); };

    absl::Status Initialize() override;

private:
    absl::Status CreateOutputDirectoryIfMissing();

    std::filesystem::path json_directory_path = "out";

    int current_file_index = 0;
};

template<>
class IntegrationContext<settings::IntegrationMode::JsonRestApi> : public IntegrationContextBase {
public:
    typedef nlohmann::json MetricsType;
    explicit IntegrationContext(
        const settings::GeneralSettings& general_settings,
        const settings::IntegrationSettings<settings::IntegrationMode::JsonRestApi>& integration_settings
    );

    absl::Status HandlePreprocessedData(const nlohmann::json& json, mediapipe::Timestamp output_timestamp);

    absl::Status OnFrameProcessed(mediapipe::Timestamp frame_timestamp) override;

    std::function<absl::Status(const MetricsType&)> OnMetricsOutput = [](const MetricsType&){ return absl::OkStatus(); };

    absl::Status Initialize() override;

private:
    std::filesystem::path output_path;
    physiology::web_client::WebClient web_api_client;
    const double metrics_server_response_reporting_interval_s = 5.0;
    const double metrics_server_response_timeout = 20.0;
    int batch_index = 0;

    bool preprocessed_data_uploaded = false;
    mediapipe::Timestamp preprocessed_data_upload_time;
    int i_server_query_interval = 0;
    bool print_metrics = true;
    bool write_metrics_to_file = true;
};


} // namespace presage::smartspectra::container
